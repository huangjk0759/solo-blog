title: docker命令
date: '2019-12-01 00:36:57'
updated: '2019-12-01 00:36:57'
tags: [待分类]
permalink: /articles/2019/12/01/1575131817342.html
---
更新yum   
sudo yum update  
  
安装需要的软件包 yun-util 提供yum-config-manager管理  
 sudo yum install -y yum-utils device-mapper-persistent-data lvm2  
  
设置yum源为阿里云  
 sudo yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo  
  ~~~~
安装docker  
 sudo yum install docker-ce  
  
卸载  
yum remove docker-*

container 容器
# docker container ls  列出正在运行的容器
# docker container ls --all  列出所有的容器
# docker ps 列出正在运行的容器
# docker ps -a 列出所有的容器

	停止和启动容器

docker stop 容器名称或者id
docker start 容器名称或者id

目录挂载 容器和目录映射
docker run -di -v /usr/local/myhtml:/usr/local/myhtml --name=mycentos centos:7
     

查看运行的容器
docker ps 

查看所有容器
docker ps -a

查看容器ip
docker inspect mycentos
删除
docker rm 容器名

查看最后一次运行的容器
docker ps -l

查看停止的容器
docker ps -f status=exited


创建交互式容器,进入即开启,退出则关闭
docker run -it --name=mydocker 容器名 /bin/bash

以守护线程方式创建容器,在后台运行
docker run -di --name=mycentos2 centos:7

创建容器 ,new对象
docker run -di/it --name 容器名(随便起)  -p 宿主机port：容器服务IP  -v 宿主机的目录：容器的目录  镜像名字/id:tag

停止和启动容器
docker start 容器名称
docker stop 容器名称

进入容器
docker exec -it myceos2 /bin/bash


文件拷贝
docker cp 需要拷贝的文件或者目录  容器名称:容器目录
docker cp 容器名称:容器目录 需要拷贝的文件或者目录





查看版本
docker -v


查看镜像命令
docker images

拉取镜像
docker pull 镜像名称
下载centos7
docker pull centos:7

删除镜像
docker rmi 镜像ID

删除所有
docker rmi `docker images -q`

# docker search mysql  查看远程仓库的镜像

设置ustc的镜像
vim /etc/docker/daemon.json

输入
{
 "registry-mirrors" : ["https://docker.mirrors.ustc.edu.cn"]
}

阿里云
{
 "registry-mirrors" : ["https://pee6w651.mirror.aliyuncs.com"]
}



{
  "registry-mirrors" :  ["https://registry.docker-cn.com"，"http://hub-mirror.c.163.com" , "https://pee6w651.mirror.aliyuncs.com" ]
}

{
  "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn"], #镜像加速地址
  "insecure-registries": ["harbor.test.com","registry.cn-shenzhen.aliyuncs.com"], # Docker如果需要从非SSL源管理镜像，这里加上。
  "max-concurrent-downloads": 10
}

docker开启命令
systemctl start docker

停止
systemctl stop docker

重启
systemctl restart docker

查看状态
systemctl status docker

开启启动
systemctl enable docker

查看docker概要信息
docker info

查看docker帮助文档
docker --help




